# Frogger

Work on Processing 3 (in Java).

Press `←` `↑` `→` `↓` to control the frog. Don't hit by a car and Do step on a log!

![image](https://github.com/Shuo-Niu/Frogger/blob/master/demo.gif)
